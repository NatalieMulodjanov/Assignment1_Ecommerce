<?php 
    /**
     *  Creates the application. Deleting this will render the application unusable.
     *  Authors: Natalie Mulodjanov (1956449), Ron Friedman (1926133), Vanier College 2021
     *  Date: 
     *  This code is/will be published on GitHub. The license is GPLv3. Please do not remove this comment
     */ 
    include('app/init.php');
    new \app\core\App();
?>