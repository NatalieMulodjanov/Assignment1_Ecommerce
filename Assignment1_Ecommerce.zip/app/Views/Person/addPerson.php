<html>
    <head>
        <title>Add Person</title>
    </head>
    <body>
        <form action='' method='post'>
            Person First Name: <input type='text' name='f_name'><br>
            Person Last Name: <input type='text' name='l_name'><br>
            Person Notes: <input type='text' name='notes'><br> 
            <input type='submit' name="submit" value='Add Person'>
        </form>
    </body>
</html>