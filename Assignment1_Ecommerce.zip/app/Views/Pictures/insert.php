<html>
    <head>
        <title>Add Picture</title>
    </head>
    <body>
        <form action='' method='post'>
            Person ID: <input type='text' name='person_id' disabled value="<?php echo $data[1] ?>"><br> 
            Description: <input type='text' name='description'><br>
            <input type='submit' name="submit" value='Add Picture'>
        </form>
    </body>
</html>